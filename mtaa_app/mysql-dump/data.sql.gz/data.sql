-- Adminer 4.8.1 MySQL 8.0.28 dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

SET NAMES utf8mb4;

DROP TABLE IF EXISTS `Places`;
CREATE TABLE `Places` (
  `uniqueID` int unsigned NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `shortDescription` text NOT NULL,
  `longDescription` text NOT NULL,
  `photo` binary(1) NOT NULL,
  `placeType` int unsigned NOT NULL,
  `location` text NOT NULL,
  PRIMARY KEY (`uniqueID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `Places` (`uniqueID`, `name`, `shortDescription`, `longDescription`, `photo`, `placeType`, `location`) VALUES
(1,	'Eat & Meet',	'studentska jedalen',	'nechutna studentska jedalen',	UNHEX('00'),	1,	'atriaky'),
(2,	'Restauracia chrappa',	'kebab',	'dobry kebab',	UNHEX('00'),	1,	'ruzinov'),
(3,	'restauracia herceg',	'hranolky',	'dlhe hranolky',	UNHEX('00'),	1,	'nitra'),
(4,	'bratislavsky hrad',	'svieti',	'svieti na bielo',	UNHEX('00'),	2,	'bratislava vedla dankovho stlpu');

DROP TABLE IF EXISTS `Reviews`;
CREATE TABLE `Reviews` (
  `placeUID` int NOT NULL,
  `userUsername` text NOT NULL,
  `reviewText` text NOT NULL,
  `revPhoto` binary(1) NOT NULL,
  `rating` smallint NOT NULL,
  `reviewID` int NOT NULL AUTO_INCREMENT,
  `userUID` int NOT NULL,
  PRIMARY KEY (`reviewID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `Reviews` (`placeUID`, `userUsername`, `reviewText`, `revPhoto`, `rating`, `reviewID`, `userUID`) VALUES
(2,	'marek',	'krasna restika',	UNHEX('00'),	5,	1,	3),
(2,	'jano',	'super',	UNHEX('00'),	5,	2,	5),
(1,	'jano',	'zle',	UNHEX('00'),	1,	3,	5);

DROP TABLE IF EXISTS `Users`;
CREATE TABLE `Users` (
  `userUID` int NOT NULL AUTO_INCREMENT,
  `isAdmin` tinyint unsigned NOT NULL,
  `username` text NOT NULL,
  `pwHash` text NOT NULL,
  PRIMARY KEY (`userUID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


-- 2022-03-24 08:39:41
